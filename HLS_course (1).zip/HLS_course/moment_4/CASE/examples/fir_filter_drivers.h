#ifndef FIR_FILTER_DRIVERS_H_INCLUDED
#define FIR_FILTER_DRIVERS_H_INCLUDED

#include "sample_buffer_csr.h"

// Read and write macros for the component
#define sample_read(offset)                     
#define sample_write(offset, data)              

// Read and write macros for sample_buffer memory
#define sample_memory_read(offset)              
#define sample_memory_write(offset, data)       

// Read and write macros for result_buffer memory
#define result_memory_read(offset)              
#define result_memory_write(offset, data)       

// Component register macros
#define sample_enable_interrupt()               
#define sample_disable_interrupt()              
#define sample_clear_done_status()              
#define sample_start()                          
#define sample_busy()                           
#define sample_done()                           

#endif
