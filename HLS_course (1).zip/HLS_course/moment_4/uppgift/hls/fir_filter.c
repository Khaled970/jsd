/*!
  file          fir_filter.c
  company       HLS
  details       FIR-filter with streaming interface
  date changed  2022-06-01
*/

#include "HLS/hls.h"
#include <stdio.h>

#define COEFFICIENTS 8
#define SAMPLE_SIZE 320

// Sample buffer supplies input to FIR-filter (used for verification/validation)
hls_avalon_slave_component component 
void sample_buffer(hls_avalon_slave_memory_argument(SAMPLE_SIZE*sizeof(float)) float* sample_buffer,
                   ihc::stream_out<float>& sample_out) {
    for (int i = 0; i < SAMPLE_SIZE; ++i){
        sample_out.write(sample_buffer[i]);
    }
}

// FIR-filter
component void fir_filter(ihc::stream_in<float>& fir_in,
                          ihc::stream_out<float>& fir_out){
    static const float coeffs[COEFFICIENTS] = {0.180603,0.045044,0.723145,0.347412,0.660522,0.383850,0.627319,0.021606};
    static float taps[COEFFICIENTS];
    float y = 0.0;

    // shift in input data
    #pragma unroll
    for(int i = (COEFFICIENTS - 1); i > 0; --i) {
        taps[i] = taps[i-1];
    }
    taps[0] = fir_in.read();

    // accumulate over all taps
    #pragma unroll
    for(int i = (COEFFICIENTS - 1); i >= 0; --i) {
        y += taps[i] * coeffs[i];
    }
    fir_out.write(y);
}

// Result buffer stores output from FIR-filter (used for verification/validation)
component void result_buffer(hls_avalon_slave_memory_argument(SAMPLE_SIZE*sizeof(float)) float* result_buffer,
                             ihc::stream_in<float>& result_in) {
    for (int i = 0; i < SAMPLE_SIZE; ++i){
        result_buffer[i] = result_in.read();
    }
}

// Verification function
void fir_filter_tb(float* sample, float* result){
    const float coeffs[COEFFICIENTS] = {0.180603,0.045044,0.723145,0.347412,0.660522,0.383850,0.627319,0.021606};
    float taps[COEFFICIENTS] = {0.0};

    for(int j = 0; j < SAMPLE_SIZE; ++j){
        float y = 0.0;
        for(int i = (COEFFICIENTS - 1); i > 0; --i){
            taps[i] = taps[i-1];
        }
        taps[0] = sample[j];

        for(int i = (COEFFICIENTS - 1); i >= 0; --i){
            y += taps[i] * coeffs[i];
        }
        result[j] = y;
    }
}

// Testbench
int main (void)
{
    float sample_output[SAMPLE_SIZE];
    float fir_output[SAMPLE_SIZE];
    float results[SAMPLE_SIZE];
    float results_tb[SAMPLE_SIZE];

    // Samples (16-bit precision)
    float samples[320] = {0.325806,0.345764,0.311218,0.352112,0.325806,0.368164,0.331116,0.378479,0.345825,0.375366,0.352539,0.384155,0.364746,0.392883,0.406799,0.397827,0.427124,0.405396,0.428772,0.407532,0.444519,0.421265,0.462097,0.441833,0.465759,0.448181,0.480347,0.449280,0.498962,0.458923,0.511108,0.485596,0.504700,0.490173,0.524780,0.497925,0.525940,0.518066,0.548157,0.519226,0.552429,0.517456,0.547485,0.540344,0.564087,0.546021,0.577698,0.548035,0.563477,0.545410,0.570679,0.553589,0.598572,0.568726,0.600586,0.568054,0.610535,0.568115,0.615723,0.577209,0.618286,0.582947,0.620728,0.592407,0.621826,0.598022,0.627075,0.606689,0.617676,0.590271,0.630188,0.608154,0.638123,0.600098,0.620483,0.609131,0.621521,0.595703,0.633423,0.614868,0.636719,0.613403,0.637939,0.609436,0.621460,0.601685,0.620911,0.602783,0.621521,0.611938,0.619568,0.599060,0.621887,0.594482,0.618530,0.592468,0.611511,0.582764,0.602112,0.596008,0.613770,0.572449,0.604919,0.578552,0.593445,0.577271,0.583740,0.560547,0.599976,0.569885,0.587524,0.545471,0.573303,0.557251,0.556763,0.539429,0.558594,0.523010,0.553589,0.526550,0.532349,0.517151,0.524048,0.513916,0.534363,0.492554,0.520996,0.479675,0.497131,0.487183,0.503296,0.465088,0.494873,0.450256,0.476318,0.461121,0.469421,0.439941,0.463257,0.422729,0.447998,0.414124,0.431885,0.400330,0.429932,0.389404,0.412781,0.385071,0.405457,0.383484,0.385986,0.369446,0.368042,0.349243,0.372803,0.346924,0.362427,0.322693,0.355347,0.309509,0.330688,0.302551,0.315735,0.292603,0.301636,0.275818,0.297913,0.270630,0.292114,0.252686,0.263916,0.234131,0.274048,0.234497,0.252930,0.225708,0.241150,0.209106,0.225586,0.197205,0.218689,0.184814,0.216919,0.170654,0.195801,0.166870,0.196533,0.152710,0.183228,0.148987,0.155457,0.127930,0.159485,0.116089,0.151001,0.106201,0.145264,0.102722,0.132996,0.106689,0.108459,0.084167,0.108398,0.092102,0.092712,0.079590,0.089600,0.063416,0.096802,0.071289,0.075195,0.051331,0.076904,0.039734,0.072632,0.038635,0.060120,0.047241,0.063660,0.028870,0.064270,0.039490,0.042419,0.026306,0.050964,0.015930,0.031860,0.011658,0.040039,0.018127,0.036011,0.007324,0.039185,0.013306,0.031860,0.004761,0.022888,0.008057,0.029785,0.017578,0.040894,0.001465,0.023315,0.007385,0.028809,0.019897,0.037720,0.012634,0.024414,0.006836,0.039612,0.020996,0.050354,0.020630,0.047974,0.012939,0.052979,0.031738,0.044739,0.020386,0.044128,0.042603,0.061279,0.027588,0.072327,0.044800,0.069763,0.036255,0.072754,0.046204,0.081299,0.054443,0.095886,0.071533,0.091309,0.069092,0.111023,0.074829,0.124573,0.102112,0.108643,0.088074,0.124451,0.100891,0.129944,0.116089,0.153809,0.126892,0.149963,0.136414,0.160889,0.151794,0.165466,0.144409,0.191406,0.163269,0.188843,0.172119,0.219116,0.179749,0.215942,0.203125,0.229675,0.202820,0.233276,0.230347,0.258911,0.224670,0.250488,0.247864,0.284424,0.250854,0.273071,0.272705,0.290955,0.270386,0.318726,0.289063,0.323486,0.299438};

    // Streams
    ihc::stream_out<float> sample_out;
    ihc::stream_in<float> fir_in;
    ihc::stream_out<float> fir_out;
    ihc::stream_in<float> result_in;



    /////// Sample buffer Testbench ///////
    sample_buffer(samples, sample_out);                                // Call sample-buffer
    for (int i = 0; i < SAMPLE_SIZE; ++i){
        sample_output[i] = sample_out.read();                          // Read output-stream
    }
    /////// Sample buffer Testbench ///////



    /////// FIR-filter Testbench ///////
    for (int i = 0; i < SAMPLE_SIZE; ++i){
        fir_in.write(sample_output[i]);                                // Populate input-stream
    }

    for (int i = 0; i < SAMPLE_SIZE; ++i){
        ihc_hls_enqueue_noret(&fir_filter, fir_in, fir_out);           // Enqueue FIR-filter invocations
    }

    ihc_hls_component_run_all(fir_filter);                             // Run all enqueued invocations

    for (int i = 0; i < SAMPLE_SIZE; ++i){
        fir_output[i] = fir_out.read();                                // Read output-stream
    }
    /////// FIR-filter Testbench ///////



    /////// Result buffer Testbench ///////
    for (int i = 0; i < SAMPLE_SIZE; ++i){
        result_in.write(fir_output[i]);                                // Populate input-stream
    }
    ihc_hls_enqueue_noret(&result_buffer, results, result_in);         // Enqueue result-buffer invocations
    ihc_hls_component_run_all(result_buffer);                          // Run all enqueued invocations
    /////// Result buffer Testbench ///////



    // Call verification function
    fir_filter_tb(samples, results_tb);

    // Check total diff of last 100 results
    float diff, tot_diff = 0.0;
    for (int i= (SAMPLE_SIZE-100);i < SAMPLE_SIZE;i++){
        diff =  results[i] - results_tb[i];
        tot_diff += diff;
    }

    printf("TOTAL ERROR =%2.6f\n",tot_diff);

    float error_margin = 1.0;
    if (tot_diff < error_margin && tot_diff > -(error_margin)){
        printf("\nTEST PASSED!\n");
    }

    else{
        printf("\nTEST FAILED!\n");
    }

    return 0;
}