#ifndef MULT_DRIVER_H_INCLUDED
#define MULT_DRIVER_H_INCLUDED

#include "mult_csr.h"

// Read and write macros for the component
#define mult_read(offset)                    IORD_32DIRECT  (   ???   , offset)
#define mult_write(offset, data)             IOWR_32DIRECT  (   ???   , offset, data)

// Read and write macros for onchip memory
#define onchip_memory_read(offset)           IORD_32DIRECT  (   ???   , offset)
#define onchip_memory_write(offset, data)    IOWR_32DIRECT  (   ???   , offset, data)

// Component register macros
#define mult_enable_interrupt()              mult_write     (MULT_CSR_INTERRUPT_ENABLE_REG, MULT_CSR_INTERRUPT_ENABLE_MASK & 0x1)
#define mult_disable_interrupt()             mult_write     (MULT_CSR_INTERRUPT_ENABLE_REG, MULT_CSR_INTERRUPT_ENABLE_MASK & 0x0)
#define mult_clear_done_status()             mult_write     (MULT_CSR_INTERRUPT_STATUS_REG, MULT_CSR_INTERRUPT_STATUS_MASK & 0x1)
#define mult_start()                         mult_write     (MULT_CSR_START_REG, MULT_CSR_START_MASK & 0x1)
#define mult_busy()                          mult_read      (MULT_CSR_BUSY_REG) & MULT_CSR_BUSY_MASK
#define mult_done()                          mult_read      (MULT_CSR_INTERRUPT_STATUS_REG) & MULT_CSR_INTERRUPT_STATUS_MASK

// Argument/Returndata register macros
#define mult_arg_N(data)                     mult_write     (   ???   ,   ???   & data)
#define mult_returndata()                    mult_read      (   ???   ) &   ???

#endif
