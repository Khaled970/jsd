/*!
  file          main.c
  company       HLS
  details       Program to validate mult
  date changed  2022-06-01
 */

#include "mult_driver.h"
#include "altera_avalon_timer_regs.h"
#include <io.h>
#include <stdio.h>
#include "system.h"

#define SAMPLE_SIZE 16

// function for verification/execution time comparison
float mult_test(float sample[SAMPLE_SIZE], int N){

float mul = 1.0;
    for (unsigned i = 0; i < N; i++){
        mul = mul * sample[i];
    }

    return mul;
}

int main(){
    float tot_diff = 0;
    float comp_result;
    float test_result;
    float samples[SAMPLE_SIZE] = {1.180617, 1.045051, 1.723173, 1.347438, 1.660617, 1.383869,
                                  1.627347, 1.021650, 1.910570, 1.800559, 1.745847, 1.813113,
                                  1.383306, 1.617279, 1.575495, 1.530052};

    // Disable interrupt and clear interrupt status register
    mult_disable_interrupt();
    mult_clear_done_status();

    // Load samples in local memory
    for (int i=0;i<SAMPLE_SIZE;i++){
        onchip_memory_write((i*sizeof(alt_32)), *(alt_32 *) (&samples[i]));
    }

    // Call components
    mult_arg_N(SAMPLE_SIZE);
    while (mult_busy()){}
    mult_start();
    while (!(mult_done())){}
    *(alt_32*) (&comp_result) = mult_returndata();

    // Call comparison function
    test_result = mult_test(samples, SAMPLE_SIZE);

    // Check results
    tot_diff = test_result - comp_result;
    printf("Result from component: \t %f\n", comp_result);
    printf("Result from function: \t %f\n", test_result);
    printf("TOTAL ERROR: \t\t =%f\n",tot_diff);

    if (tot_diff < 0.0002 && tot_diff > -0.0002){
        printf("\nTEST PASSED!\n");
    }

    else{
        printf("\nTEST FAILED!\n");
    }

    return 0;
}

