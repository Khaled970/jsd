/*!
  file          mult.c
  company       HLS
  details       Multiplies new input with product of last multiplication operation
  date changed  2022-06-01
*/

#include "HLS/hls.h"
#include <stdio.h>            // For printf

#define SAMPLE_SIZE 16

// component
hls_avalon_slave_component component 
float mult(ihc::mm_master<float, ihc::aspace<1>, ihc::awidth<32>, ihc::dwidth<32> > &a,
           hls_avalon_slave_register_argument int N){

    float mul = 1.0;
    for (unsigned i = 0; i < N; i++){
        mul = mul * a[i];
    }

    return mul;
}

// Verification function
float mult_test(float sample[SAMPLE_SIZE], int N){

    float mul = 1.0;
    for (unsigned i = 0; i < N; i++){
        mul = mul * sample[i];
    }

    return mul;
}

int main(){
    float tot_diff = 0.0;
    float comp_result;
    float test_result;
    float samples[SAMPLE_SIZE] = {1.180617, 1.045051, 1.723173, 1.347438, 1.660617, 1.383869,
                                  1.627347, 1.021650, 1.910570, 1.800559, 1.745847, 1.813113,
                                  1.383306, 1.617279, 1.575495, 1.530052};

    // mm_master interface class instance
    ihc::mm_master<float, ihc::aspace<1>, ihc::awidth<32>, ihc::dwidth<32> > a_tb(samples, sizeof(float)*SAMPLE_SIZE);

    // Call design under test
    comp_result = mult(a_tb, SAMPLE_SIZE);

    // Call verification function
    test_result = mult_test(samples, SAMPLE_SIZE);

    // Check results
    tot_diff = test_result - comp_result;
    printf("Result from component: \t %f\n", comp_result);
    printf("Result from function: \t %f\n", test_result);
    printf("TOTAL ERROR: \t\t =%f\n", tot_diff);

    if (tot_diff < 0.0002 && tot_diff > -0.0002){
        printf("\nTEST PASSED!\n");
    }

    else{
        printf("\nTEST FAILED!\n");
    }

    return 0;
}
