/*!
  file          counter.c
  company       HLS
  details       Simple counter returning count-value.
                count increases by 1 when key_in is '1' then '0'.
  date changed  2022-06-01
 */

#include <stdio.h>                      // For printf

#define TEST_SAMPLES 4

// Function
unsigned char counter(bool key_in){

    static bool ctl;                    // Control signal for KEY pressed/released
    static unsigned char count;

    if (key_in == 0 && ctl == 1){       // Counts up by 1 if KEY is pressed
        count++;
        ctl = 0;
    }
   
    if (key_in == 1 && ctl == 0){       // Sets control signal to 1 if KEY is released
        ctl = 1;
    }

    return count;
}

// Main function
int main() {
    unsigned char result[TEST_SAMPLES];

    // Call counter function
    result[0] = counter(1);
    result[1] = counter(0);
    result[2] = counter(1);
    result[3] = counter(0);

    // Print Results
    for(int i=0;i<TEST_SAMPLES;i++){
        printf("%d\n", (int) result[i]);
    }

    return 0;
}
